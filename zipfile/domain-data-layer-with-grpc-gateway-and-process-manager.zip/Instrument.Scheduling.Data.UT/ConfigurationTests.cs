namespace Instrument.Scheduler.Data.UT;

using Instrument.Scheduler.Data.Configuration;

public class ConfigurationTests
{
    [Fact]
    public void StorageConfiguration_SqliteProvider_InitializesCorrectly()
    {
        // Arrange
        var config = new Instrument.Scheduler.Data.Configuration.StorageConfiguration
        {
            Provider = Instrument.Scheduler.Data.Configuration.StorageProviderType.SQLite,
            ConnectionString = "Data Source=test.db"
        };
        
        // Act & Assert
        Assert.Equal(Instrument.Scheduler.Data.Configuration.StorageProviderType.SQLite, config.Provider);
        Assert.Equal("Data Source=test.db", config.ConnectionString);
    }

    [Fact]
    public void StorageConfiguration_SqlServerProvider_InitializesCorrectly()
    {
        // Arrange
        var config = new Instrument.Scheduler.Data.Configuration.StorageConfiguration
        {
            Provider = Instrument.Scheduler.Data.Configuration.StorageProviderType.SqlServer,
            ConnectionString = "Server=test;Database=TestDb;Trusted_Connection=True;"
        };
        
        // Act & Assert
        Assert.Equal(Instrument.Scheduler.Data.Configuration.StorageProviderType.SqlServer, config.Provider);
        Assert.Equal("Server=test;Database=TestDb;Trusted_Connection=True;", config.ConnectionString);
    }

    [Fact]
    public void StorageProviderType_HasExpectedValues()
    {
        // Act & Assert
        Assert.Equal(0, (int)Instrument.Scheduler.Data.Configuration.StorageProviderType.SQLite);
        Assert.Equal(1, (int)Instrument.Scheduler.Data.Configuration.StorageProviderType.SqlServer);
    }
}