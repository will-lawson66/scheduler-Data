namespace Instrument.Scheduler.Data.UT;

using System;
using Instrument.Scheduler.Data;
using Instrument.Scheduler.Data.Configuration;
using Instrument.Scheduler.Data.DataContext;
using Instrument.Scheduler.Data.Entities;
using Instrument.Scheduler.Data.Services.Cleanup;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;

public class ServiceCollectionExtensionsTests
{
    [Fact]
    public void AddSchedulerDataLayer_RegistersSqliteServices_WhenSqliteProviderSpecified()
    {
        // Arrange
        var services = new ServiceCollection();
        
        // Add logging services required by our updated services
        services.AddLogging(builder => builder.AddConsole());

        Mock<IConfigurationSection> configSectionMock = new();
        configSectionMock.Setup(cs => cs.Value).Returns("value");

        var config = new Instrument.Scheduler.Data.Configuration.StorageConfiguration
        {
            Provider = Instrument.Scheduler.Data.Configuration.StorageProviderType.SQLite,
        };

        Mock<IConfiguration> configMock = new();
        configMock.Setup(c => c.GetSection(It.IsAny<string>())).Returns(configSectionMock.Object);

        // Act
        services.AddSchedulingDataLayer(configMock.Object);


        // Assert
        var provider = services.BuildServiceProvider();
        
        // Verify service registrations
        var dbContext = provider.GetService<Instrument.Scheduler.Data.DataContext.SchedulerDbContext>();
        var sequenceProvider = provider.GetService<IStorageProvider<Instrument.Scheduler.Data.Entities.Sequence>>();
        var parameterProvider = provider.GetService<IStorageProvider<Instrument.Scheduler.Data.Entities.Parameter>>();
        var sequenceParameterProvider = provider.GetService<IStorageProvider<Instrument.Scheduler.Data.Entities.SequenceParameter>>();
        var rangeProvider = provider.GetService<IStorageProvider<Entities.Range>>();
        var rangeValueProvider = provider.GetService<IStorageProvider<Instrument.Scheduler.Data.Entities.RangeValue>>();
        var resourceProvider = provider.GetService<IStorageProvider<Instrument.Scheduler.Data.Entities.Resource>>();
        
        Assert.NotNull(dbContext);
    }
    
    [Fact]
    public void AddSchedulerDataLayer_RegistersRepositories()
    {
        // Arrange
        var services = new ServiceCollection();
        
        // Add logging services required by our updated services
        services.AddLogging(builder => builder.AddConsole());

        Mock<IConfigurationSection> configSectionMock = new();
        configSectionMock.Setup(cs => cs.Value).Returns("value");

        var config = new Instrument.Scheduler.Data.Configuration.StorageConfiguration
        {
            Provider = Instrument.Scheduler.Data.Configuration.StorageProviderType.SQLite,
        };

        Mock<IConfiguration> configMock = new();
        configMock.Setup(c => c.GetSection(It.IsAny<string>())).Returns(configSectionMock.Object);
        
        // Act
        services.AddSchedulingDataLayer(configMock.Object);
        
        // Assert
        var provider = services.BuildServiceProvider();
        
        var sequenceRepo = provider.GetService<ISequenceRepository>();
        var parameterRepo = provider.GetService<IParameterRepository>();
        var rangeRepo = provider.GetService<IRangeRepository>();
        var rangeValueRepo = provider.GetService<IRangeValueRepository>();
        var resourceRepo = provider.GetService<IResourceRepository>();
        
        Assert.NotNull(sequenceRepo);
        Assert.NotNull(parameterRepo);
        Assert.NotNull(rangeRepo);
        Assert.NotNull(rangeValueRepo);
        Assert.NotNull(resourceRepo);
    }
    
    [Fact]
    public void AddCleanupServices_RegistersCleanupServices()
    {
        // Arrange
        var services = new ServiceCollection();
        
        // Add required services first
        services.AddLogging(builder => builder.AddConsole());
        
        // Add a mock DbContext for dependency resolution
        services.AddDbContext<Instrument.Scheduler.Data.DataContext.SchedulerDbContext>(options => 
            options.UseInMemoryDatabase("TestDb"));
            
        // Act
        services.AddCleanupServices();
        
        // Assert
        var provider = services.BuildServiceProvider();
        var dbCleanupService = provider.GetService<Instrument.Scheduler.Data.Services.Cleanup.DatabaseCleanupService>();
        
        Assert.NotNull(dbCleanupService);
    }
    
    [Fact]
    public void AddSchedulerDataLayer_ThrowsException_WhenConfigIsNull()
    {
        // Arrange
        var services = new ServiceCollection();
        
        // Act & Assert
        Assert.Throws<NullReferenceException>(() => services.AddSchedulingDataLayer(null!));
    }
    
    //[Fact]
    //public void AddSchedulerDataWithInitialization_ThrowsException_WhenConfigIsNull()
    //{
    //    // Arrange
    //    var services = new ServiceCollection();
        
    //    // Act & Assert
    //    Assert.Throws<NullReferenceException>(() => services.AddSchedulingDataLayerWithInitialization(null!));
    //}
}
