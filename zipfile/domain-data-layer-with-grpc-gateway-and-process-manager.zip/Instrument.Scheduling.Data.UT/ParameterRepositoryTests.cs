namespace Instrument.Scheduler.Data.UT;

using System;
using Microsoft.EntityFrameworkCore;

public class ParameterRepositoryTests : IDisposable
{
    private readonly DataContext.SchedulerDbContext _dbContext;

    public ParameterRepositoryTests()
    {
        var dbName = $"TestDB_{Guid.NewGuid()}";
        var options = new DbContextOptionsBuilder<DataContext.SchedulerDbContext>()
            .UseInMemoryDatabase(databaseName: dbName)
            .Options;
        
        _dbContext = new DataContext.SchedulerDbContext(options);
    }

    public void Dispose()
    {
        // Clean up database after test
        _dbContext.Database.EnsureDeleted();
        _dbContext.Dispose();
    }
}
