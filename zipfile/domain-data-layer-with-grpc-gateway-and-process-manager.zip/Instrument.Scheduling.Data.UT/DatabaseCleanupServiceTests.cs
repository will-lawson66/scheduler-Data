﻿namespace Instrument.Scheduler.Data.UT;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Instrument.Execution.Parameter;
using Instrument.Scheduler.Data.Initialization;
using Instrument.Scheduler.Data.DataContext;
using Instrument.Scheduler.Data.Entities;
using Instrument.Scheduler.Data.Services.Cleanup;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using Microsoft.Data.Sqlite;

public class DatabaseCleanupServiceTests : IDisposable
{
    private readonly Instrument.Scheduler.Data.DataContext.SchedulerDbContext _dbContext;
    private readonly Mock<ILogger<Instrument.Scheduler.Data.Services.Cleanup.DatabaseCleanupService>> _mockLogger;
    private readonly Instrument.Scheduler.Data.Services.Cleanup.DatabaseCleanupService _service;
    private readonly SqliteConnection _connection;
    private readonly Instrument.Scheduler.Data.Initialization.SqliteDatabaseInitializer _databaseInitializer;
    private readonly string _databasePath;

    public DatabaseCleanupServiceTests()
    {
        // Create a unique database file for each test instance
        _databasePath = Path.Combine(Path.GetTempPath(), $"test_scheduler_{Guid.NewGuid()}.db");

        // Ensure the directory exists
        var directory = Path.GetDirectoryName(_databasePath);
        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
        {
            Directory.CreateDirectory(directory);
        }

        _connection = new SqliteConnection($"Data Source={_databasePath}");

        var sqliteOptions = new DbContextOptionsBuilder<Instrument.Scheduler.Data.DataContext.SchedulerDbContext>()
            .UseSqlite(_connection)
            .Options;

        _dbContext = new Instrument.Scheduler.Data.DataContext.SchedulerDbContext(sqliteOptions);
        _mockLogger = new Mock<ILogger<Instrument.Scheduler.Data.Services.Cleanup.DatabaseCleanupService>>();
        _service = new Instrument.Scheduler.Data.Services.Cleanup.DatabaseCleanupService(_dbContext, _mockLogger.Object);
        _databaseInitializer = new Instrument.Scheduler.Data.Initialization.SqliteDatabaseInitializer(_dbContext, new NullLogger<Instrument.Scheduler.Data.Initialization.SqliteDatabaseInitializer>());
    }

    public void Dispose()
    {
        try
        {
            _dbContext.Database.EnsureDeleted();
        }
        catch (Exception ex)
        {
            // Log but don't fail the test
            System.Diagnostics.Debug.WriteLine($"Warning: Failed to delete database in Dispose: {ex.Message}");
        }

        _dbContext.Dispose();
        _connection.Close();
        _connection.Dispose();

        // Clean up the temporary database file
        try
        {
            if (File.Exists(_databasePath))
            {
                File.Delete(_databasePath);
            }
        }
        catch (Exception ex)
        {
            // Log but don't fail the test
            System.Diagnostics.Debug.WriteLine($"Warning: Failed to delete database file: {ex.Message}");
        }
    }

    [Fact]
    public async Task ClearAllDataAsync_WithEmptyDatabase_CompletesSuccessfully()
    {
        // Arrange - Initialize the database schema
        await _databaseInitializer.InitializeAsync();

        // Act
        await _service.ClearAllDataAsync();

        // Assert - Should complete without throwing
        Assert.True(true); // Test passes if no exception is thrown
    }

    [Fact]
    public async Task ClearAllDataAsync_WithUninitializedDatabase_CompletesSuccessfully()
    {
        // Act - Should handle uninitialized database gracefully
        await _service.ClearAllDataAsync();

        // Assert - Should complete without throwing
        Assert.True(true); // Test passes if no exception is thrown
    }

    [Fact]
    public async Task ClearAllDataAsync_WithDataInAllTables_ClearsAllData()
    {
        // Arrange - Create test data in all tables
        await InitializeAndSeedTestDataAsync();

        // Verify data exists before cleanup
        Assert.True(await _dbContext.Parameters.AnyAsync());
        Assert.True(await _dbContext.Sequences.AnyAsync());
        Assert.True(await _dbContext.SequenceGroups.AnyAsync());
        Assert.True(await _dbContext.Ranges.AnyAsync());
        Assert.True(await _dbContext.Resources.AnyAsync());
        Assert.True(await _dbContext.RangeValues.AnyAsync());
        Assert.True(await _dbContext.SequenceParameters.AnyAsync());
        Assert.True(await _dbContext.SequenceGroupSequences.AnyAsync());
        Assert.True(await _dbContext.SequenceGroupCollections.AnyAsync());

        // Act
        await _service.ClearAllDataAsync();

        // Assert - All tables should be empty
        Assert.False(await _dbContext.Parameters.AnyAsync());
        Assert.False(await _dbContext.Sequences.AnyAsync());
        Assert.False(await _dbContext.SequenceGroups.AnyAsync());
        Assert.False(await _dbContext.Ranges.AnyAsync());
        Assert.False(await _dbContext.Resources.AnyAsync());
        Assert.False(await _dbContext.RangeValues.AnyAsync());
        Assert.False(await _dbContext.SequenceParameters.AnyAsync());
        Assert.False(await _dbContext.SequenceGroupSequences.AnyAsync());
        Assert.False(await _dbContext.SequenceGroupCollections.AnyAsync());
        Assert.False(await _dbContext.SequenceGroupCollectionSequenceGroups.AnyAsync());
    }

    [Fact]
    public async Task ClearAllDataAsync_WithForeignKeyConstraints_DeletesInCorrectOrder()
    {
        // Arrange - Initialize database first
        await _databaseInitializer.InitializeAsync();

        // Create data with foreign key relationships
        var range = new Entities.Range { Name = "Test Range", Description = "Test" };
        await _dbContext.Ranges.AddAsync(range);
        await _dbContext.SaveChangesAsync();

        var rangeValue = new Instrument.Scheduler.Data.Entities.RangeValue
        {
            RangeId = range.Id,
            Name = "Test Value",
            Value = "test"
        };
        await _dbContext.RangeValues.AddAsync(rangeValue);

        var resource = new Instrument.Scheduler.Data.Entities.Resource { Name = "Test Resource", Code = "TR001" };
        await _dbContext.Resources.AddAsync(resource);
        await _dbContext.SaveChangesAsync();

        var parameter = new Instrument.Scheduler.Data.Entities.Parameter
        {
            Name = "Test Parameter",
            Type = ParameterType.StringType,
            ResourceId = resource.Id
        };
        await _dbContext.Parameters.AddAsync(parameter);

        var sequence = new Instrument.Scheduler.Data.Entities.Sequence
        {
            Name = "Test Sequence",
            WorstCaseTime = TimeSpan.FromSeconds(30)
        };
        await _dbContext.Sequences.AddAsync(sequence);
        await _dbContext.SaveChangesAsync();

        var sequenceParameter = new Instrument.Scheduler.Data.Entities.SequenceParameter
        {
            SequenceId = sequence.Id,
            ParameterId = parameter.Id,
            OrderNumber = 1
        };
        await _dbContext.SequenceParameters.AddAsync(sequenceParameter);
        await _dbContext.SaveChangesAsync();

        // Act - Should not throw constraint violations
        var exception = await Record.ExceptionAsync(() => _service.ClearAllDataAsync());

        // Assert
        Assert.Null(exception);
    }

    [Fact]
    public async Task ClearAllDataAsync_LogsCorrectMessages()
    {
        // Arrange
        await InitializeAndSeedTestDataAsync();

        // Act
        await _service.ClearAllDataAsync();

        // Assert - Verify logging calls
        _mockLogger.Verify(
            x => x.Log(
                LogLevel.Information,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("Beginning database cleanup operation")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);

        _mockLogger.Verify(
            x => x.Log(
                LogLevel.Information,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("Database cleanup completed successfully")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }

    [Fact]
    public void Constructor_WithNullContext_ThrowsArgumentNullException()
    {
        // Act & Assert
        Assert.Throws<ArgumentNullException>(() =>
            new Instrument.Scheduler.Data.Services.Cleanup.DatabaseCleanupService(null!, _mockLogger.Object));
    }

    [Fact]
    public void Constructor_WithNullLogger_ThrowsArgumentNullException()
    {
        // Act & Assert
        Assert.Throws<ArgumentNullException>(() =>
            new Instrument.Scheduler.Data.Services.Cleanup.DatabaseCleanupService(_dbContext, null!));
    }

    [Fact]
    public async Task ClearAllDataAsync_WithLargeDataset_ClearsEfficiently()
    {
        // Arrange - Initialize database first
        await _databaseInitializer.InitializeAsync();

        // Create a larger dataset
        var ranges = Enumerable.Range(1, 100)
            .Select(i => new Entities.Range { Name = $"Range {i}", Description = $"Description {i}" })
            .ToList();
        await _dbContext.Ranges.AddRangeAsync(ranges);
        await _dbContext.SaveChangesAsync();

        var rangeValues = new List<Instrument.Scheduler.Data.Entities.RangeValue>();
        foreach (var range in ranges)
        {
            for (int j = 1; j <= 5; j++)
            {
                rangeValues.Add(new Instrument.Scheduler.Data.Entities.RangeValue
                {
                    RangeId = range.Id,
                    Name = $"Value {j}",
                    Value = j.ToString()
                });
            }
        }
        await _dbContext.RangeValues.AddRangeAsync(rangeValues);
        await _dbContext.SaveChangesAsync();

        // Verify large dataset exists
        Assert.Equal(100, await _dbContext.Ranges.CountAsync());
        Assert.Equal(500, await _dbContext.RangeValues.CountAsync());

        // Act
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        await _service.ClearAllDataAsync();
        stopwatch.Stop();

        // Assert
        Assert.Equal(0, await _dbContext.Ranges.CountAsync());
        Assert.Equal(0, await _dbContext.RangeValues.CountAsync());

        // Should complete in reasonable time (less than 5 seconds for this dataset)
        Assert.True(stopwatch.Elapsed < TimeSpan.FromSeconds(5),
            $"Cleanup took too long: {stopwatch.Elapsed}");
    }

    [Fact]
    public async Task ClearAllDataAsync_WithNonExistentTables_HandlesGracefully()
    {
        // Arrange - Don't initialize database, so tables don't exist

        // Act - Should handle non-existent tables gracefully
        var exception = await Record.ExceptionAsync(() => _service.ClearAllDataAsync());

        // Assert - Should not throw
        Assert.Null(exception);
    }

    [Fact]
    public async Task ClearAllDataAsync_WithPartiallyInitializedDatabase_HandlesGracefully()
    {
        // Arrange - Only create some tables manually
        await _dbContext.Database.EnsureCreatedAsync();

        // Drop some tables to simulate partial initialization
        await _dbContext.Database.ExecuteSqlRawAsync("DROP TABLE IF EXISTS SequenceParameters");

        // Act - Should handle missing tables gracefully
        var exception = await Record.ExceptionAsync(() => _service.ClearAllDataAsync());

        // Assert - Should not throw
        Assert.Null(exception);
    }

    private async Task InitializeAndSeedTestDataAsync()
    {
        await _databaseInitializer.InitializeAsync();

        // Create test data in all tables to verify complete cleanup
        var range = new Entities.Range { Name = "Test Range", Description = "Test" };
        await _dbContext.Ranges.AddAsync(range);

        var resource = new Instrument.Scheduler.Data.Entities.Resource { Name = "Test Resource", Code = "TR001" };
        await _dbContext.Resources.AddAsync(resource);

        var sequence = new Instrument.Scheduler.Data.Entities.Sequence
        {
            Name = "Test Sequence",
            WorstCaseTime = TimeSpan.FromSeconds(30)
        };
        await _dbContext.Sequences.AddAsync(sequence);

        var sequenceGroup = new Instrument.Scheduler.Data.Entities.SequenceGroup
        {
            Name = "Test Group",
            Description = "Test Group Description"
        };
        await _dbContext.SequenceGroups.AddAsync(sequenceGroup);

        var sequenceGroupCollection = new Instrument.Scheduler.Data.Entities.SequenceGroupCollection<TestEnum>
        {
            Name = "Test Collection",
            Category = TestEnum.CategoryA
        };
        await _dbContext.SequenceGroupCollections.AddAsync(sequenceGroupCollection);

        await _dbContext.SaveChangesAsync();

        // Add child records
        var rangeValue = new Instrument.Scheduler.Data.Entities.RangeValue
        {
            RangeId = range.Id,
            Name = "Test Value",
            Value = "test"
        };
        await _dbContext.RangeValues.AddAsync(rangeValue);

        var parameter = new Instrument.Scheduler.Data.Entities.Parameter
        {
            Name = "Test Parameter",
            Type = ParameterType.StringType,
            ResourceId = resource.Id
        };
        await _dbContext.Parameters.AddAsync(parameter);

        await _dbContext.SaveChangesAsync();

        var sequenceParameter = new Instrument.Scheduler.Data.Entities.SequenceParameter
        {
            SequenceId = sequence.Id,
            ParameterId = parameter.Id,
            OrderNumber = 1
        };
        await _dbContext.SequenceParameters.AddAsync(sequenceParameter);

        var sequenceGroupSequence = new Instrument.Scheduler.Data.Entities.SequenceGroupSequence
        {
            SequenceGroupId = sequenceGroup.Id,
            SequenceId = sequence.Id,
            Order = 1
        };
        await _dbContext.SequenceGroupSequences.AddAsync(sequenceGroupSequence);

        var sequenceGroupCollectionSequenceGroup = new Instrument.Scheduler.Data.Entities.SequenceGroupCollectionSequenceGroup
        {
            SequenceGroupCollectionId = sequenceGroupCollection.Id,
            SequenceGroupId = sequenceGroup.Id,
            Order = 1
        };
        await _dbContext.SequenceGroupCollectionSequenceGroups.AddAsync(sequenceGroupCollectionSequenceGroup);

        await _dbContext.SaveChangesAsync();
    }

    private enum TestEnum
    {
        CategoryA,
        CategoryB
    }
}