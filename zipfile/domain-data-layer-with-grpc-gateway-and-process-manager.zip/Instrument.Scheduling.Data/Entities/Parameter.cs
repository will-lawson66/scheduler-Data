namespace Instrument.Scheduler.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Instrument.Execution.Parameter;

/// <summary>
/// A hardware component operational parameter (volume, position, etc.)
/// </summary>
public record Parameter
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; init; }
    public required string Name { get; init; }
    public required ParameterType Type { get; init; }
    public string? Min { get; init; }
    public string? Max { get; init; }
    public string? DefaultValue { get; init; }
    public string? Format { get; init; }
    
    [ForeignKey(nameof(Range))]
    public int? RangeId { get; init; }
    
    [ForeignKey(nameof(Resource))]
    public int? ResourceId { get; set; }
    
    // Navigation properties
    public Range? Range { get; init; }
    public Resource? Resource { get; init; }
    public List<SequenceParameter> SequenceParameters { get; set; } = [];
    
    // Update method - returns a new instance with the specified changes
    public Parameter Update(
        string? name = null, 
        ParameterType? type = null, 
        string? min = null, 
        string? max = null, 
        string? defaultValue = null, 
        string? format = null, 
        int? rangeId = null,
        int? resourceId = null)
    {
        // Validate updates if needed
        if (name != null && string.IsNullOrWhiteSpace(name))
        {
            throw new ArgumentException("Name cannot be empty", nameof(name));
        }
            
        // Use record's "with" expression for creating a modified copy
        return this with 
        {
            Name = name ?? Name,
            Type = type ?? Type,
            Min = min ?? Min,
            Max = max ?? Max,
            DefaultValue = defaultValue ?? DefaultValue,
            Format = format ?? Format,
            RangeId = rangeId ?? RangeId,
            ResourceId = resourceId ?? ResourceId
        };
    }
}
