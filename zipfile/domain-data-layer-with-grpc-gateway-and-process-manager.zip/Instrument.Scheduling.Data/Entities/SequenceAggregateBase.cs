namespace Instrument.Scheduler.Data.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

/// <summary>
/// A base class defining a basic header for groups of sequences.
/// </summary>
public abstract record SequenceAggregateBase
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; init; }
    public required string Name { get; init; }
    public string? Description { get; init; }
}
