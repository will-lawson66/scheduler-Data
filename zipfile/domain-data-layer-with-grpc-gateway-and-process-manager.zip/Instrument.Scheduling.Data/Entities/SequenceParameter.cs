namespace Instrument.Scheduler.Data.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

/// <summary>
/// Join entity linking <see cref="Sequence"/> and <see cref="Parameter"/>
/// </summary>
public record SequenceParameter
{
    [Key]
    [Column(Order = 0)]
    [ForeignKey(nameof(Sequence))]
    public required int SequenceId { get; init; }
    
    [Key]
    [Column(Order = 1)]
    [ForeignKey(nameof(Parameter))]
    public required int ParameterId { get; init; }
    public int OrderNumber { get; set; }

    // Navigation properties
    public Sequence? Sequence { get; set; }
    public Parameter? Parameter { get; set; } = null!;
}
