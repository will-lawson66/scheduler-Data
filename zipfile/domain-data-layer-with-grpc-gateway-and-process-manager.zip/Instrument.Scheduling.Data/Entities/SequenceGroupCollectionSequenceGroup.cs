﻿namespace Instrument.Scheduler.Data.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

/// <summary>
/// Join table associating <see cref="SequenceGroup"/> and <see cref="SequenceGroupCollection"/> />
/// </summary>
public class SequenceGroupCollectionSequenceGroup
{
    [Key]
    [Column(Order = 0)]
    [ForeignKey(nameof(SequenceGroupCollection))]
    public required int SequenceGroupCollectionId { get; init; }
    
    [Key]
    [Column(Order = 1)]
    [ForeignKey(nameof(SequenceGroup))]
    public required int SequenceGroupId { get; init; }
    public required int Order { get; set; }

    // Navigation properties
    public SequenceGroupCollectionBase? SequenceGroupCollection { get; set; }
    public SequenceGroup? SequenceGroup { get; set; }
}
