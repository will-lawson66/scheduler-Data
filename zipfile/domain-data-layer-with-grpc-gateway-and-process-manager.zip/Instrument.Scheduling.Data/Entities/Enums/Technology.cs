namespace Instrument.Scheduler.Data.Entities.Enums;

public enum Technology
{
    ImmunoCap,
    Elia,
    ImmunoCapViewAllergy,
}
