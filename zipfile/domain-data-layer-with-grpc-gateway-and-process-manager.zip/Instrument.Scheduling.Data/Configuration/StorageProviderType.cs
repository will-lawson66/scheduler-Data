namespace Instrument.Scheduler.Data.Configuration;

public enum StorageProviderType
{
    SQLite,
    SqlServer
}
