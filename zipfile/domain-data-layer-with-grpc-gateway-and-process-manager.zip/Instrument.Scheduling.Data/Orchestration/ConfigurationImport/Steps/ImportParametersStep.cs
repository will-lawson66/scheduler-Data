﻿namespace Instrument.Scheduler.Data.Orchestration.ConfigurationImport.Steps;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Instrument.Execution.Grpc;
using Instrument.Execution.Grpc.Configuration;
using Instrument.Scheduler.Data;
using Instrument.Scheduler.Data.Entities;
using Instrument.Scheduler.Data.Orchestration;
using Instrument.Scheduler.Data.Orchestration.ConfigurationImport;
using Microsoft.Extensions.Logging;

/// <summary>
/// Step to import parameters from ExecutionConfigurationService to scheduler entities
/// </summary>
public class ImportParametersStep : IOrchestrationStep
{
    private readonly IParameterService _parameterService;
    private readonly ILogger<ImportParametersStep> _logger;

    public ImportParametersStep(
        IParameterService parameterService,
        ILogger<ImportParametersStep> logger)
    {
        _parameterService = parameterService;
        _logger = logger;
    }

    public string StepName => "ImportParameters";

    public async Task<StepResult> ExecuteAsync(OrchestrationContext context, CancellationToken cancellationToken)
    {
        try
        {
            var configuration = context.GetData<ExecutionConfigurationContract>("FetchedConfiguration");
            var statistics = context.GetData<ImportStatistics>("Statistics");
            var request = context.GetData<ConfigurationImportRequest>("ImportRequest");

            if (configuration?.Sequences == null)
            {
                return StepResult.Failure("No configuration or sequences found in context");
            }

            var distinctParameters = configuration.Sequences
                .Where(s => s.Parameters != null)
                .SelectMany(p => p.Parameters)
                .GroupBy(n => n.ParameterName)
                .Select(g => g.First())
                .ToList();


            // Apply filters if specified
            //if (request?.SequenceFilters?.Count != 0)
            //{
            //    distinctParameters = distinctParameters
            //        .Where(s => request is { SequenceFilters: not null } && request.SequenceFilters.Contains(s.Key))
            //        .ToList();
            //}

            foreach (var sequenceParameterTypeContract in distinctParameters)
            {
                await ProcessParameterAsync(sequenceParameterTypeContract);
                if (statistics != null)
                {
                    statistics.ParametersProcessed++;
                }
            }

            context.SetData("Statistics", statistics);

            _logger.LogInformation("Imported {Count} parameters successfully", statistics?.SequencesProcessed);
            return StepResult.Success();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to import parameters");
            return StepResult.Failure($"Failed to import parameters: {ex.Message}");
        }
    }

    private async Task ProcessParameterAsync(SequenceParameterTypeContract contract)
    {
        // Map SequenceParameterTypeContract to Parameter entity
        var parameter = new Parameter
        {
            Name = contract.ParameterName,
            Type = contract.ParameterType,
        };

        // Check if parameter already exists by name
        var existingParameters = await _parameterService.GetAllParametersAsync();
        var existingParameter = existingParameters.FirstOrDefault(s => s.Name == parameter.Name);

        if (existingParameter == null)
        {
            await _parameterService.CreateParameterAsync(parameter);
            _logger.LogDebug("Created new parameter: {ParameterName}", parameter.Name);
        }
        else
        {
            // Update existing parameter
            var updatedParameter = existingParameter.Update(
                name: parameter.Name,
                type: parameter.Type
                );

            await _parameterService.UpdateParameterAsync(updatedParameter);
            _logger.LogDebug("Updated existing sequence: {ParameterName}", parameter.Name);
        }
    }
}
