﻿namespace Instrument.Scheduler.Data.Orchestration;
using System.Collections.Generic;

/// <summary>
/// Context passed between orchestration steps
/// </summary>
public class OrchestrationContext
{
    public Dictionary<string, object?> Data { get; } = [];
    public List<string> CompletedSteps { get; } = [];
    public List<string> Errors { get; } = [];

    public T? GetData<T>(string key) 
    {
        if (Data.TryGetValue(key, out var value) && value is T outValue)
        {
            return outValue;
        }

        return default(T);
    }

    public void SetData<T>(string key, T value)
    {
        Data[key] = value;
    }
}
