namespace Instrument.Scheduler.Data.Repository;
using System.Threading.Tasks;
using Instrument.Scheduler.Data;
using Instrument.Scheduler.Data.DataContext;
using Instrument.Scheduler.Data.Entities;
using Microsoft.EntityFrameworkCore;

/// <summary>
/// Repository for ranges
/// </summary>
public class RangeRepository : Repository<Range>, IRangeRepository
{
    /// <summary>
    /// Creates a new range repository
    /// </summary>
    /// <param name="dbContext">Database context</param>
    public RangeRepository(SchedulerDbContext dbContext)
        : base(dbContext)
    {
    }

    /// <inheritdoc />
    public async Task<Entities.Range?> GetRangeWithRangeValuesByIdAsync(int rangeId)
    {
        return await DbContext.Ranges
            .Include(r => r.RangeValues)
            .FirstOrDefaultAsync(r => r.Id == rangeId);
    }
}