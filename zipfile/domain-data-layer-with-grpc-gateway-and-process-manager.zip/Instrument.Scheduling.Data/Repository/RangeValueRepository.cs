namespace Instrument.Scheduler.Data.Repository;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Instrument.Scheduler.Data;
using Instrument.Scheduler.Data.DataContext;
using Instrument.Scheduler.Data.Entities;
using Microsoft.EntityFrameworkCore;

/// <summary>
/// Repository for range values
/// </summary>
public class RangeValueRepository : Repository<RangeValue>, IRangeValueRepository
{
    /// <inheritdoc />
    public RangeValueRepository(SchedulerDbContext dbContext)
        : base(dbContext)
    {
    }

    /// <inheritdoc />
    public async Task<IEnumerable<RangeValue>> GetRangeValuesByRangeIdAsync(int rangeId)
    {
        return await DbContext.RangeValues
            .Where(rv => rv.RangeId == rangeId)
            .ToListAsync();
    }
}