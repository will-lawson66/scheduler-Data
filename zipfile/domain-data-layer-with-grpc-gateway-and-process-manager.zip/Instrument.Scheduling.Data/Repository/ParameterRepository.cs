namespace Instrument.Scheduler.Data.Repository;
using Instrument.Scheduler.Data;
using Instrument.Scheduler.Data.DataContext;
using Instrument.Scheduler.Data.Entities;

/// <summary>
/// Repository for parameters
/// </summary>
public class ParameterRepository : Repository<Parameter>, IParameterRepository
{
    /// <summary>
    /// Creates a new parameter repository
    /// </summary>
    /// <param name="dbContext">Database context</param>
    public ParameterRepository(SchedulerDbContext dbContext)
        : base(dbContext)
    {
    }
}