namespace Instrument.Scheduler.Data;
using System.Collections.Generic;
using System.Threading.Tasks;
using Instrument.Scheduler.Data.Entities;

/// <summary>
/// Repository interface for range values
/// </summary>
public interface IRangeValueRepository : IRepository<RangeValue>
{
    /// <summary>
    /// Gets range values by range ID
    /// </summary>
    /// <param name="rangeId">Range ID</param>
    Task<IEnumerable<RangeValue>> GetRangeValuesByRangeIdAsync(int rangeId);
}