namespace Instrument.Scheduler.Data;

using Instrument.Scheduler.Data.Entities;

/// <summary>
/// Repository interface for parameters
/// </summary>
public interface IParameterRepository : IRepository<Parameter>
{
}