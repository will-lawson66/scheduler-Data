﻿namespace Instrument.Scheduler.Data;
using System.Collections.Generic;
using System.Threading.Tasks;
using Instrument.Scheduler.Data.Entities;

public interface IRangeValueService
{
    Task<RangeValue?> GetRangeValueByIdAsync(int id);
    Task<RangeValue> CreateRangeValueAsync(RangeValue rangeValue);
    Task UpdateRangeValueAsync(RangeValue rangeValue);
    Task DeleteRangeValueAsync(int id);
    Task<IEnumerable<RangeValue>> GetAllRangeValuesAsync();

    /// <summary>
    /// Get the <see cref="Entities.RangeValue"/>s for this Range/>
    /// </summary>
    /// <param name="rangeId"></param>
    /// <returns></returns>
    Task<IEnumerable<RangeValue>> GetRangeValuesForRangeAsync(int rangeId);
}
