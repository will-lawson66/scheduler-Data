﻿namespace Instrument.Scheduler.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface IRangeService
{
    Task<Entities.Range?> GetRangeByIdAsync(int id);

    Task<Entities.Range?> GetRangeWithRangeValuesAsync(int id);

    Task<Entities.Range> CreateRangeAsync(Entities.Range range);

    Task UpdateRangeAsync(Entities.Range range);

    Task DeleteRangeAsync(int id);

    Task<IEnumerable<Entities.Range>> GetAllRangesAsync();
}
