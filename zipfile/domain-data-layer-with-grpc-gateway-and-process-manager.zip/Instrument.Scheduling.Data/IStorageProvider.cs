namespace Instrument.Scheduler.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface IStorageProvider<T> where T : class
{
    Task<IEnumerable<T>> GetAllAsync();
    Task<T?> GetByIdAsync(string id);
    Task AddAsync(T entity);
    Task UpdateAsync(T entity);
    Task DeleteAsync(string id);
    Task SaveChangesAsync();
}
